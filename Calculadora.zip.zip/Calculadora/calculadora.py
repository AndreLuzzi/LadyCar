# Calculadora em Python
def soma(a, b):
    return a + b

def subtracao(a, b):
    return a - b

def multiplicacao(a, b):
    return a * b

def divisao(a, b):
    if b == 0:
        return "Erro: divisao por zero"
    return a / b


# Parte interativa da calculadora
if __name__ == "__main__":
    num1 = float(input("Digite o primeiro numero: "))
    num2 = float(input("Digite o segundo numero: "))

    operacao = input("Escolha a operação (+, -, *, /): ")

    if operacao == '+':
        resultado = soma(num1, num2)

    elif operacao == '-':
        resultado = subtracao(num1, num2)

    elif operacao == '*':
        resultado = multiplicacao(num1, num2)

    elif operacao == '/':
        resultado = divisao(num1, num2)

    else:
        resultado = "Operação invalida"

    print("Resultado:", resultado)
