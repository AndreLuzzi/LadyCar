import pytest
from calculadora import soma, subtracao, multiplicacao, divisao


def test_soma():
    assert soma(3, 3) == 6
    assert soma(-1, 9) == 8


def test_subtracao():
    assert subtracao(10, 5) == 5


def test_multiplicacao():
    assert multiplicacao(2, 4) == 8


def test_divisao():
    assert divisao(10, 2) == 5


def test_divisao_por_zero():
    assert divisao(5, 0) == "Erro: divisao por zero"